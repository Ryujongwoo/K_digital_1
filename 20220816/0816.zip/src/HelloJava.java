
public class HelloJava {

	public static void main(String[] args) {

//		자동완성 단축키: ctrl + space
//		프로그램 실행 단축키: ctrl + F11

//		주석: 프로그램에 대한 간단한 설명을 적는다.
//		1줄 주석: 앞에 "/"를 연속해서 2개를 사용하면 그 줄은 컴파일러가 번역하지 않는다.
//		1줄 주석 단축키: ctrl + / => 누를 때 마다 주석이 지정 또는 해제된다.
//		범위 주석: "/* ~ */" 사이에 입력한 내용은 컴파일러가 번역하지 않는다.
//		범위 주석 단축키: 블록을 지정하고 ctrl + shift + /를 누르면 주석이 설정되고
//		ctrl + shift + \를 누르면 주석이 해제된다.
		
//		코드 복사 단축키: ctrl + alt + ↑(위로 복사), ctrl + alt + ↓(아래로 복사)
//		코드 이동 단축키: alt + ↑(위로 이동), alt + ↓(아래로 이동)

//		println: 괄호 안의 내용을 출력하고 줄을 바꾼다.
//		print: 괄호 안의 내용을 출력하고 줄을 바꾸지 않는다.
//		printf: 출력 서식(자리수)을 지정해서 출력한다.
		System.out.println("안녕 자바");
		System.out.print("안녕 \n자바"); // \n: new line => 줄을 바꾼다.
		System.out.println("안녕 자바");
		
	}

}
