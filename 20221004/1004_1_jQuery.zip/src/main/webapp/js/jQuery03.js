function imgSize() {
//	$('img').css('width', '200px');
//	$('img').css('height', '200px');
//	$('img').css('width', '200px').css('height', '200px');
	$('img').css({'width': '200px', 'height': '200px'});
}

function idSelector() {
//	$('#selId').css('display', 'none');
	$('#selId').hide();
}

function classSelector() {
	$('.selClass').css('opacity', '0.5');
}

















