INSERT INTO article(id, title, content) values (1, '홍길동', '천재');
INSERT INTO article(id, title, content) values (2, '임꺽정', '처언재');
INSERT INTO article(id, title, content) values (3, '장길산', '처어언재');
INSERT INTO article(id, title, content) values (4, '일지매', '처어어언재');