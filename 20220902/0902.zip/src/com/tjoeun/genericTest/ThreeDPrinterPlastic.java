package com.tjoeun.genericTest;

//	재료로 Plastic를 사용하는 3D 프린터, Plastic 전용 프린터
public class ThreeDPrinterPlastic {

	private Plastic material;

	public Plastic getMaterial() {
		return material;
	}

	public void setMaterial(Plastic material) {
		this.material = material;
	}

}
