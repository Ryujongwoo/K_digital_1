function elementCreate() {
//	요소(element)를 만들어 문서에 추가한다.
//	createElement('태그이름'): 인수로 지정된 태그를 만든다.
	let div = document.createElement('div'); // <div></div>
	
	
	
	
//	appendChild('추가할 태그 또는 문자열'): 인수로 지정된 태그 맨 뒤에 추가한다.
	document.body.appendChild(div);
	div.innerHTML = '<marquee>오늘도 고생하셨구요 3일 푹 쉬시고 다음주 화요일에 봐요.. 마치겠습니다.</marquee>'
}























