const job = new Promise((resolve, reject) => {
	setTimeout(() => {
		resolve('job ok!');
	}, 2000);
});

job.then(data => {
	console.log("data: ", data);
});

const job2 = new Promise((resolve, reject) => {
	setTimeout(() => {
		reject('job2 fail!');
	}, 2000);
});

job2.catch(error => {
	console.log("error: ", error);
});

//	==============================================================================

function job3() {
	return new Promise((resolve, reject) => {
		setTimeout(() => {
			reject('job3 fail!');
		}, 2000);
	});
}

job3().catch(error => {
	console.log("error: ", error);
})

function job4() {
	return new Promise((resolve, reject) => {
		setTimeout(() => {
			resolve('job4 ok!');
			// reject('job4 에러발생');
		}, 2000);
	});
}

/*
job4().then(data => {
	console.log("data: ", data);
});
*/

/*
job3()
	.catch(error2 => {
		console.log("error2: ", error2);
		job4()
			.then(data2 => {
				console.log("data2: ", data2);
			});
	})
*/

job4()
	.then(data3 => {
		console.log("data3: ", data3);
		return job3();
	})
	.catch(error3 => {
		console.log("error2: ", error2);
		// Promise에서 오류가 발생했을 때 Promise 객체의 reject() 함수를 실행하면 이어지는 
		// 작업을 중지할 수 있다.
		return Promise.reject(error3);
	})
	.then(data4 => {
		console.log("=====================================");
	})








