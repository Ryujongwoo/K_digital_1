package com.tjoeun.memoList;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class MemoList {

	private ArrayList<MemoVO> memoList = new ArrayList<>();

	public ArrayList<MemoVO> getMemoList() {
		return memoList;
	}
	public void setMemoList(ArrayList<MemoVO> memoList) {
		this.memoList = memoList;
	}
	
	@Override
	public String toString() {
		String str = "";
		if (memoList.size() == 0) {
			str += "저장된 메모가 없습니다.\n";
		} else {
			for (int i=memoList.size()-1; i>=0; i--) {
				str += memoList.get(i) + "\n";
			}
		}
		return str;
	}
	
	public void addMemo(MemoVO vo) {
		memoList.add(vo);
	}
	
	public MemoVO selectMemo(int idx) {
		try {
			return memoList.get(idx - 1);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}
	
	public void deleteMemo(int idx) {
		memoList.remove(idx - 1);
		for (int i=0; i<memoList.size(); i++) {
			memoList.get(i).setIdx(i + 1);
		}
		MemoVO.count = memoList.size();
	}
	
	public void updateMemo(int idx, String memo) {
		memoList.get(idx - 1).setMemo(memo);
	}
	
//	MemoMain 클래스에서 호출되는 텍스트 파일의 이름을 넘겨받아 memoList ArrayList에 저장된
//	데이터를 텍스트 파일로 출력하는 메소드
	public void writeMemo(String filename) {
		
		PrintWriter printWriter = null;
		
//		텍스트 파일의 경로와 이름을 연결한다.
//		String filepath = "./src/com/tjoeun/memoList/" + filename + ".txt";
		String filepath = String.format("./src/com/tjoeun/memoList/%s.txt", filename);
//		System.out.println(filepath);
		
		try {
			printWriter = new PrintWriter(filepath);
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
//			memoList라는 ArrayList에 저장된 데이터의 개수만큼 반복하며 텍스트 파일로 출력한다.
//			memoList에 저장된 데이터를 공백으로 구분해서 1줄로 연결해서 출력한다.
			for (int i=0; i<memoList.size(); i++) {
//				System.out.println(memoList.get(i));
				MemoVO vo = memoList.get(i);
				String str = "";
				str += vo.getIdx() + " ";
				str += vo.getName() + " ";
				str += vo.getPassword() + " ";
				str += vo.getMemo().replace(" ", "`") + " ";
				str += sdf.format(vo.getWriteDate());
				System.out.println(str);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("파일 또는 경로 이름이 올바르지 않습니다.");
		} finally {
			if (printWriter != null) {
				printWriter.close();
			}
		}
		
	}
	
}












