package com.tjoeun.springWEB_DBCP_board;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tjoeun.service.DeleteService;
import com.tjoeun.service.IncrementService;
import com.tjoeun.service.InsertService;
import com.tjoeun.service.MvcboardService;
import com.tjoeun.service.ReplyService;
import com.tjoeun.service.SelectService;
import com.tjoeun.service.UpdateService;
import com.tjoeun.service.contentViewService;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
//	JdbcTemplate을 사용하려면 servlet-context.xml 파일에서 프로젝트가 실행될 때 DriverManagerDataSource
//	클래스의 bean(데이터베이스 연결 정보)을 참조해서 생성한 JdbcTemplate 클래스의 bean을 컨트롤러에서
//	JdbcTemplate 클래스 타입의 객체를 생성하고 넣어줘야 한다.
	private JdbcTemplate template;
	
//	JdbcTemplate 클래스 타입 객체의 getter & setter를 만든다. => 사실... getter는 안만들어도 된다.
	public JdbcTemplate getTemplate() {
		return template;
	}
	
//	프로젝트를 실행하면 스프링 환경 설정 파일인 servlet-context.xml 파일이 읽혀진 다음 JdbcTemplate
//	클래스 객체의 setter 메소드가 자동으로 실행되게 하기 위해서 @Autowired 어노테이션을 붙여준다.
//	@Autowired을 붙여준 메소드는 서버가 구동되는 단계에서 자동으로 실행되며 setter의 인수 template으로
//	스프링이 알아서 setvlet-context.xml 파일에서 생성한 JdbcTemplate 클래스의 bean을 자동으로 전달한다.
//	setter 메소드는 자동으로 전달받은 JdbcTemplate 클래스의 bean으로 JdbcTemplate 클래스 객체를 
//	초기화시킨다.
	@Autowired // @Autowired 어노테이션을 붙여서 선언 메소는 서버 구동 단계에서 자동으로 실행된다.
	public void setTemplate(JdbcTemplate template) {
		System.out.println("꺄오~~~~~~~~~~");
		this.template = template;
		
//		여기까지 정상적으로 실행되면 컨트롤러에서 JdbcTemplate을 사용할 수 있게된다.
//		데이터베이스 연결은 주로 DAO 클래스에서 하므로 컨트롤러 이외의 클래스에서 JdbcTemplate을
//		사용할 수 있게 하기 위해서 적당한 이름의 패키지(base-package)에 적당한 이름의 클래스(Constant)를
//		만들고 적당한 이름으로 작성한 클래스의 정적 필드(public static JdbcTemplate template)에
//		setvlet-context.xml 파일에서 생성된 JdbcTemplate 클래스의 bean을 넣어준다.
		
//		적당한 이름으로 클래스를 만들고 JdbcTemplate 객체를 static으로 선언한 후 코딩한다.
		Constant.template = this.template;
	}

	@RequestMapping("/")
	public String start(Locale locale, Model model) {
		logger.info("start()");
		return "redirect:list";
	}
	
	@RequestMapping("/insert")
	public String insert(HttpServletRequest request, Model model) {
		logger.info("insert()");
		return "insert";
	}
	
	@RequestMapping("/insertOK")
	public String insertOK(HttpServletRequest request, Model model) {
		logger.info("insertOK() - Model 인터페이스 객체 사용");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("insert", InsertService.class);
		service.execute(model);
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String list(HttpServletRequest request, Model model) {
		logger.info("list()");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("select", SelectService.class);
		service.execute(model);
		return "list";
	}
	
	@RequestMapping("/increment")
	public String increment(HttpServletRequest request, Model model) {
		logger.info("increment()");
		logger.info("idx: {}, currentPage: {}", request.getParameter("idx"), request.getParameter("currentPage"));
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("increment", IncrementService.class);
		service.execute(model);
		model.addAttribute("idx", request.getParameter("idx"));
		model.addAttribute("currentPage", request.getParameter("currentPage"));
		return "redirect:contentView";
	}
	
	@RequestMapping("/contentView")
	public String contentView(HttpServletRequest request, Model model) {
		logger.info("contentView()");
		logger.info("idx: {}, currentPage: {}", request.getParameter("idx"), request.getParameter("currentPage"));
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("contentView", contentViewService.class);
		service.execute(model);
		return "contentView";
	}
	
	@RequestMapping("/update")
	public String update(HttpServletRequest request, Model model) {
		logger.info("update()");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("update", UpdateService.class);
		service.execute(model);
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		logger.info("delete()");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("delete", DeleteService.class);
		service.execute(model);
		return "redirect:list";
	}
	
	@RequestMapping("/reply")
	public String reply(HttpServletRequest request, Model model) {
		logger.info("reply()");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("contentView", contentViewService.class);
		service.execute(model);
		return "reply";
	}
	
	@RequestMapping("/replyInsert")
	public String replyInsert(HttpServletRequest request, Model model) {
		logger.info("replyInsert()");
		model.addAttribute("request", request);
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardService service = ctx.getBean("reply", ReplyService.class);
		service.execute(model);
		return "redirect:list";
	}
	
}














