package com.tjoeun.memoList;

import java.util.Scanner;

//	데이터를 테이블에 저장, 테이블에 저장된 데이터의 수정, 삭제 및 조회 작업을 실행하기
//	전에 필요한 전처리 작업을 실행하는 클래스
public class MemoService {

//	데이터를 입력받아 DAO 클래스로 넘겨주는 메소드
	public static void insert() {
		
//		전처리
//		테이블에 저장할 데이터를 입력받는다.
		Scanner scanner = new Scanner(System.in);
		System.out.print("이름: ");
		String name = scanner.nextLine().trim();
		System.out.print("비밀번호: ");
		String password = scanner.nextLine().trim();
		System.out.print("메모: ");
		String memo = scanner.nextLine().trim();

//		입력받은 데이터를 MemoVO 클래스 객체를 만들어 저장한다.
		MemoVO vo = new MemoVO();
		vo.setName(name);
		vo.setPassword(password);
		vo.setMemo(memo);
		
//		입력받은 데이터를 테이블에 저장하는 DAO 클래스의 메소드를 호출한다.
		boolean result = MemoDAO.insert(vo);
		
//		후처리
		if (result) {
			System.out.println(name + "님 글 저장완료");
		} else {
			System.out.println("저장실패!!!");
		}
		
	}

	
	
}






