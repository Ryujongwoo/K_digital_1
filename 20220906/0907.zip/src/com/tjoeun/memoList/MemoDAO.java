package com.tjoeun.memoList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//	MemoService 클래스에서 전처리 작업이 완료되서 넘어온 데이터로 sql 명령을 실행하는 클래스
public class MemoDAO {

//	테이블에 저장할 데이터가 저장된 MemoVO 클래스 객체를 넘겨받아 테이블에 데이터를 저장하는
//	메소드
	public static boolean insert(MemoVO vo) {
		
		boolean result = true;
		
//		데이터베이스 작업에 사용할 객체를 선언한다.
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
//			mysql에 연결한다.
			conn = DBUtil.getMySQLConnection();
//			sql 명령을 만든다.
			String sql = "insert into memo(name, password, memo) values (?, ?, ?)";
//			sql 명령을 임시로 실행한다.
			pstmt = conn.prepareStatement(sql);
//			"?"에 데이터를 넣어준다.
			pstmt.setString(1, vo.getName());
			pstmt.setString(2, vo.getPassword());
			pstmt.setString(3, vo.getMemo());
//			"?"가 채워진 sql 명령을 최종적으로 실행한다.
			pstmt.executeUpdate();
//			System.out.println(vo.getName() + "님 글 저장완료");
		} catch (SQLException e) {
//			e.printStackTrace();
			System.out.println("sql 명령이 올바르게 실행되지 않았습니다.");
			result = false;
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return result;
	}

}















