// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-analytics.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
apiKey: "AIzaSyAVvB9cMvr5HbE5QgT-oPJExxviGbPu308",
authDomain: "node-85da3.firebaseapp.com",
projectId: "node-85da3",
storageBucket: "node-85da3.appspot.com",
messagingSenderId: "899136133815",
appId: "1:899136133815:web:ce4ba3a4246cfc7b750b32",
measurementId: "G-5YTVLL73ND"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);