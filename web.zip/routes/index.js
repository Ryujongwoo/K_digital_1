var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: '한빛미디어', pageName: 'home.ejs' });
});

// 로그인 페이지 이동
router.get('/login', function(req, res, next) {
  res.render('index', { title: '한빛미디어', pageName: 'user/login.ejs' });
});

// 게시글 목록 페이지 이동
router.get('/posts', function(req, res, next) {
  res.render('index', { title: '한빛미디어', pageName: 'post/list.ejs' });
});

// 글쓰기 페이지 이동
router.get('/writer', function(req, res, next) {
  res.render('index', { title: '한빛미디어', pageName: 'post/writer.ejs' });
});

// 글읽기 페이지 이동
router.get('/posts/:id', function(req, res, next) {
  const id = req.params.id;
  res.render('index', { title: '한빛미디어', pageName: 'post/read.ejs', id: id });
});


module.exports = router;
