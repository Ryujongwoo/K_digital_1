package com.tjoeun.genericTest;

//	3D 프린터 재료 - Powder
public class Water {

	@Override
	public String toString() {
		return "Water";
	}
	
}
